define(function(){
    var app = angular.module('app', ['ngRoute', 'ngResource', 'ngTable','ui.bootstrap']);
    return app;
});

   

    


