﻿
'use strict';
define(['app'], function (app) {

    app.directive('employeeInfo', [employeeInfo]);

    function employeeInfo() {
        return {
            templateUrl: "../app/template/employeeInfo.html",
            restrict: "E",
            controller: function ($scope, ngTableParams) {
                $scope.users = [
                                { name: "Madhav Sai", age: 10, gender: 'Nagpur', dob: '25/08/2013'},
                                { name: "Suresh Dasari", age: 30, gender: 'Chennai', dob: '25/08/2013' },
                                { name: "Rohini Alavala", age: 29, gender: 'Chennai', dob: '25/08/2013' },
                                { name: "Praveen Kumar", age: 25, gender: 'Bangalore', dob: '25/08/2013' },
                                { name: "Sateesh Chandra", age: 27, gender: 'Vizag', dob: '25/08/2013' },
                                { name: "Siva Prasad", age: 38, gender: 'Nagpur', dob: '25/08/2013' },
                                { name: "Sudheer Rayana", age: 25, gender: 'Kakinada', dob: '25/08/2013' },
                                { name: "Honey Yemineni", age: 7, gender: 'Nagpur', dob: '25/08/2013' },
                                { name: "Mahendra Dasari", age: 22, gender: 'Vijayawada', dob: '25/08/2013' },
                                { name: "Mahesh Dasari", age: 23, gender: 'California', dob: '25/08/2013' },
                                { name: "Nagaraju Dasari", age: 34, gender: 'Atlanta', dob: '25/08/2013' },
                                { name: "Gopi Krishna", age: 29, gender: 'Repalle', dob: '25/08/2013' },
                                { name: "Sudheer Uppala", age: 19, gender: 'Guntur', dob: '25/08/2013' },
                                { name: "Sushmita", age: 27, gender: 'Vizag', dob: '25/08/2013' }
                ];

                $scope.usersTable = new ngTableParams({
                    page: 1,
                    count: 5
                }, {
                    total: $scope.users.length,
                    getData: function ($defer, params) {
                        $scope.data = $scope.users.slice((params.page() - 1) * params.count(), params.page() * params.count());
                        $defer.resolve($scope.data);
                    }
                });
            }
        }
    }
});


