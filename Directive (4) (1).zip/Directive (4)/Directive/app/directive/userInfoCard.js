﻿'use strict';
define(['app'], function (app) {

    app.directive('userInfoCard', [userInfoCard]);

    function userInfoCard() {
        return {
            template: "Name: {{user.name}}",
            restrict:"E"
        }
    }
});

