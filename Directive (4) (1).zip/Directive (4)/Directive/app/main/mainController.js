﻿'use strict';
define(['app'], function (app) {

     app.controller('mainController', ['$scope', mainController]);


    function mainController($scope) {

            $scope.user = {
                name: "Prakash Pandey"
            }

        }
});