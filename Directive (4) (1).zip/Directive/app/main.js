﻿/// <reference path="Scripts/angular-resource.js" />

require.config({
    baseUrl: 'app',
    paths: {
        'angular': '/Directive/Scripts/angular',
    },
    shim: {
        //'blockUI': ['angular'],
        //'angular-translate' : ['angular'],
        //'angular-translate-loader-partial': ['angular'],
        //'angular-animate': ['angular']
    }

});

require(
    [
        'app',
        'main/mainController',
        'directive/userInfoCard',

    ]
    ,
    function () {
        angular.bootstrap(document, ['app']);
    }

    );