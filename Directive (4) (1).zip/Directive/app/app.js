define(function(){
    angular.module('app', []);
});

   

    


